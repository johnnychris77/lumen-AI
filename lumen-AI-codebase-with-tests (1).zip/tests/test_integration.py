from lumenai import integration

def test_log_result_captures_output(capsys):
    integration.log_result("Instrument123", {"status": "PASS", "confidence": 0.95})
    captured = capsys.readouterr()
    assert "Instrument123" in captured.out
    assert "PASS" in captured.out
