from lumenai import imaging

def test_capture_test_image_returns_string():
    img = imaging.capture_test_image()
    assert isinstance(img, str)
    assert img != ""
