def log_result(instrument_id, result):
    # Placeholder: send results to SPM/CensiTrac API
    print(f"Logging {instrument_id}: {result}")
