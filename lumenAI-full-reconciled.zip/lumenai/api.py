from fastapi import FastAPI
from lumenai import inference
try:
    from prometheus_fastapi_instrumentator import Instrumentator
    _HAS_METRICS = True
except Exception:
    _HAS_METRICS = False
app = FastAPI(title='LumenAI API', version='0.1.0')
@app.on_event('startup')
def _startup():
    if _HAS_METRICS:
        Instrumentator().instrument(app).expose(app)
@app.get('/')
def root():
    return {'message':'Welcome to LumenAI API'}
@app.get('/health')
def health():
    return {'status':'ok'}
@app.post('/predict')
def predict():
    return inference.analyze_image('dummy_image_data')
