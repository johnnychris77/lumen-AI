def log_result(instrument_id, result):
    print(f'Logging {instrument_id}: {result}')
