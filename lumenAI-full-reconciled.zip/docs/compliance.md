# Compliance Considerations
- AAMI ST79
- AORN guidelines
- CDC recommendations
- FDA regulations (21 CFR Part 11)
