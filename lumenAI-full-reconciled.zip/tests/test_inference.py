from lumenai import inference

def test_analyze_image_structure():
    result = inference.analyze_image('dummy')
    assert isinstance(result, dict)
    assert set(result.keys()) == {'status','confidence'}
    assert result['status'] in {'PASS','FAIL'}
    assert 0.0 <= result['confidence'] <= 1.0
