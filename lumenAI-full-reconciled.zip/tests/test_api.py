from fastapi.testclient import TestClient
from lumenai.api import app

def test_health_ok():
    c = TestClient(app); r = c.get('/health')
    assert r.status_code == 200 and r.json().get('status')=='ok'

def test_root_welcome():
    c = TestClient(app); r = c.get('/')
    assert r.status_code == 200 and 'Welcome' in r.json().get('message','')
