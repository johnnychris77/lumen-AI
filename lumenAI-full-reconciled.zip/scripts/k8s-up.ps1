Param()
$ErrorActionPreference = 'Stop'
function Say($m) { Write-Host "[k8s-up] $m" }
try { kubectl cluster-info | Out-Null; Say "Kubernetes reachable: $(kubectl config current-context)"; exit 0 } catch {}
try { kubectl config use-context docker-desktop | Out-Null; kubectl cluster-info | Out-Null; Say "Using docker-desktop"; exit 0 } catch {}
try { if (Get-Command minikube -ErrorAction SilentlyContinue) { Say "Trying Minikube…"; try { minikube status | Out-Null } catch { minikube start --driver=docker | Out-Null }; kubectl config use-context minikube | Out-Null; kubectl cluster-info | Out-Null; Say "Using minikube"; exit 0 } } catch {}
try { if (Get-Command kind -ErrorAction SilentlyContinue) { Say "Trying kind…"; $c = kind get clusters | Out-String; if ($c -notmatch "^kind$") { kind create cluster | Out-Null }; kubectl cluster-info --context kind-kind | Out-Null; kubectl config use-context kind-kind | Out-Null; Say "Using kind-kind"; exit 0 } } catch {}
Say "No cluster available. Enable Docker Desktop Kubernetes or install Minikube/kind."; exit 1
