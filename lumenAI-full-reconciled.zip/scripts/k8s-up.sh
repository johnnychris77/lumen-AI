#!/usr/bin/env bash
set -euo pipefail
say(){ echo "[k8s-up] $*"; }
if kubectl cluster-info >/dev/null 2>&1; then say "Kubernetes reachable: $(kubectl config current-context)"; exit 0; fi
if kubectl config use-context docker-desktop >/dev/null 2>&1 && kubectl cluster-info >/dev/null 2>&1; then say "Using docker-desktop"; exit 0; fi
if command -v minikube >/dev/null 2>&1; then say "Trying Minikube…"; minikube status >/dev/null 2>&1 || minikube start --driver=docker; kubectl config use-context minikube >/dev/null 2>&1 || true; kubectl cluster-info >/dev/null 2>&1 && { say "Using minikube"; exit 0; }; fi
if command -v kind >/dev/null 2>&1; then say "Trying kind…"; kind get clusters | grep -q '^kind$' || kind create cluster; kubectl cluster-info --context kind-kind >/dev/null 2>&1 && { kubectl config use-context kind-kind >/dev/null 2>&1 || true; say "Using kind-kind"; exit 0; }; fi
echo "[k8s-up] No cluster available. Enable Docker Desktop Kubernetes or install Minikube/kind."; exit 1
