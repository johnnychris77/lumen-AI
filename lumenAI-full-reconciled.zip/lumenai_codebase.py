#!/usr/bin/env python3
from lumenai import imaging, inference, integration

if __name__=='__main__':
    print('🚀 Starting LumenAI...')
    img = imaging.capture_test_image()
    result = inference.analyze_image(img)
    integration.log_result('Instrument123', result)
    print(result)
