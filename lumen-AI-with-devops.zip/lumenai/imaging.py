def capture_test_image():
    return 'dummy_image_data'
