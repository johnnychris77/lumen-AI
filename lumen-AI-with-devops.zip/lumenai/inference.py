def analyze_image(image):
    return {'status':'PASS','confidence':0.95}
