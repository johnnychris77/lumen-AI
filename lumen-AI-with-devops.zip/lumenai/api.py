from fastapi import FastAPI
from lumenai import inference
app=FastAPI(title='LumenAI API')
@app.get('/health')
def h():
    return {'status':'ok'}
