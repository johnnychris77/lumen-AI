#!/usr/bin/env python3
from lumenai import imaging, inference, integration
if __name__=='__main__':
    img=imaging.capture_test_image()
    res=inference.analyze_image(img)
    integration.log_result('Instrument123',res)
    print(res)
