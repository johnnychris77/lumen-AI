from fastapi import HTTPException

def require_role(user, allowed: list[str]):
    if user.role not in allowed:
        raise HTTPException(403, detail="Insufficient role")
