from fastapi import FastAPI
from pydantic import BaseModel
from lumenai import inference

app = FastAPI(title="LumenAI Inference API", version="0.1.0")

class PredictRequest(BaseModel):
    image_b64: str | None = None

class PredictResponse(BaseModel):
    status: str
    confidence: float

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/predict", response_model=PredictResponse)
def predict(req: PredictRequest):
    result = inference.analyze_image(req.image_b64 or "dummy_image_data")
    return PredictResponse(**result)
