import streamlit as st
from lumenai import inference

st.set_page_config(page_title="LumenAI Demo", layout="centered")
st.title("LumenAI — Lumen Inspection Demo")

uploaded = st.file_uploader("Upload an image (mocked)", type=["png", "jpg", "jpeg"])

if uploaded is not None:
    st.image(uploaded, caption="Uploaded image", use_column_width=True)
    result = inference.analyze_image("dummy_image_data")
    st.subheader("Result")
    st.json(result)
else:
    st.info("Upload an image to simulate analysis.")
