# LumenAI — AI-Powered Lumen Inspection

LumenAI is a fiber‑optic borescope + AI software stack for inspecting lumened surgical instruments.
See README in Canvas for full details.

## Quickstart
python -m venv .venv
# activate env then:
pip install -r requirements.txt
python lumenai_codebase.py
