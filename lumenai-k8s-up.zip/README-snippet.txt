## Bring up a local cluster (one-liner)

### Git Bash / WSL / macOS / Linux
bash scripts/k8s-up.sh && helm upgrade --install lumenai ./helm/lumenai --set image.repository=ghcr.io/johnnychris77/lumen-AI --set image.tag=latest

### Windows PowerShell
powershell -ExecutionPolicy Bypass -File scripts\k8s-up.ps1
helm upgrade --install lumenai .\helm\lumenai `
  --set "image.repository=ghcr.io/johnnychris77/lumen-AI" `
  --set "image.tag=latest"
