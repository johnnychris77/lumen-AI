#!/usr/bin/env bash
set -euo pipefail
say() { echo "[k8s-up] $*"; }

# Already reachable?
if kubectl cluster-info >/dev/null 2>&1; then
  say "Kubernetes already reachable: $(kubectl config current-context)"
  exit 0
fi

# Docker Desktop
if kubectl config use-context docker-desktop >/dev/null 2>&1; then
  if kubectl cluster-info >/dev/null 2>&1; then
    say "Using docker-desktop context"
    exit 0
  fi
fi

# Minikube
if command -v minikube >/dev/null 2>&1; then
  say "Trying Minikube…"
  minikube status >/dev/null 2>&1 || minikube start --driver=docker
  kubectl config use-context minikube >/dev/null 2>&1 || true
  if kubectl cluster-info >/dev/null 2>&1; then
    say "Using minikube context"
    exit 0
  fi
fi

# kind
if command -v kind >/dev/null 2>&1; then
  say "Trying kind…"
  if ! kind get clusters | grep -q '^kind$'; then
    kind create cluster
  fi
  if kubectl cluster-info --context kind-kind >/dev/null 2>&1; then
    kubectl config use-context kind-kind >/dev/null 2>&1 || true
    say "Using kind-kind context"
    exit 0
  fi
fi

say "No Kubernetes cluster available. Enable Docker Desktop Kubernetes or install Minikube/kind."
exit 1
