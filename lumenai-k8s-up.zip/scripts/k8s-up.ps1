Param()
$ErrorActionPreference = 'Stop'
function Say($msg) { Write-Host "[k8s-up] $msg" }

# Already reachable?
try {
  kubectl cluster-info | Out-Null
  Say "Kubernetes already reachable: $(kubectl config current-context)"
  exit 0
} catch {}

# Docker Desktop
try {
  kubectl config use-context docker-desktop | Out-Null
  kubectl cluster-info | Out-Null
  Say "Using docker-desktop context"
  exit 0
} catch {}

# Minikube
try {
  if (Get-Command minikube -ErrorAction SilentlyContinue) {
    Say "Trying Minikube…"
    try { minikube status | Out-Null } catch { minikube start --driver=docker | Out-Null }
    kubectl config use-context minikube | Out-Null
    kubectl cluster-info | Out-Null
    Say "Using minikube context"
    exit 0
  }
} catch {}

# kind
try {
  if (Get-Command kind -ErrorAction SilentlyContinue) {
    Say "Trying kind…"
    $clusters = kind get clusters | Out-String
    if ($clusters -notmatch "^kind$") { kind create cluster | Out-Null }
    kubectl cluster-info --context kind-kind | Out-Null
    kubectl config use-context kind-kind | Out-Null
    Say "Using kind-kind context"
    exit 0
  }
} catch {}

Say "No Kubernetes cluster available. Enable Docker Desktop Kubernetes or install Minikube/kind."
exit 1
